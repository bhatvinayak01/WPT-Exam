const express = require("express");
const app = express();
app.use(express.json());
const cors = require("cors");
app.use(cors());

const { addMessage, selectMessage } = require("./user");
const res = require("express/lib/response");

app.get("/message", async (req, res) => {
  const list = await selectMessage();
  res.json(list);
});

app.post("/add-message", async (req, res) => {
  const message = req.body;
  await addMessage(message);
  res.json({ message: "Message added successfully !!!" });
});

app.listen(4000, () => console.log("Server Started !!!"));

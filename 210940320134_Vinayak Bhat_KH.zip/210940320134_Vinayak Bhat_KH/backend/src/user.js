const mysql = require("mysql");
const Promise = require("bluebird");
Promise.promisifyAll(require("mysql/lib/Connection").prototype);

const dbinfo = {
  host: "localhost",
  user: "root",
  password: "cdac",
  database: "project2",
};

async function connectionCheck() {
  const connection = mysql.createConnection(dbinfo);
  await connection.connectAsync();
  console.log("Connected Successfully !!!");
  await connection.endAsync();
}

async function addMessage(message) {
  const connection = mysql.createConnection(dbinfo);
  await connection.connectAsync();
  console.log("Connected !!!");
  let sql = `insert into message(chat) values (?)`;
  await connection.queryAsync(sql, [message.chat]);
  await connection.endAsync();
}

//const message = { chat: "Hello Everyone" };
//addMessage(message);

async function selectMessage(message) {
  const connection = mysql.createConnection(dbinfo);
  await connection.connectAsync();
  console.log("Connected !!!");
  let sql = `select * from message`;
  const list = await connection.queryAsync(sql, []);
  await connection.endAsync();
  //console.log(list);
  return list;
}

selectMessage();

module.exports = { addMessage, selectMessage };

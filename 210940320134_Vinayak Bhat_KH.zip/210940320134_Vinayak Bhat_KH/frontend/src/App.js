import axios from "axios";
import { useEffect, useState } from "react";

export default function App() {
  return (
    <>
      <MyComponent />
    </>
  );
}

function MyComponent() {
  const [chat, setChat] = useState("");
  const [send, setSend] = useState("");
  const [list, setList] = useState([]);

  const handleChatChange = (e) => {
    setChat(e.target.value);
  };

  const addMessage = async () => {
    const url = "http://localhost:4000/add-message";
    const data = {
      chat: chat,
    };

    const newList = [data, ...list];
    setList(newList);
    await axios.post(url, data);
    setChat("");
  };

  const getMessage = async () => {
    const url1 = "http://localhost:4000/message";
    const result = await axios.get(url1);

    const newList = [...result.data];
    setList(newList);
  };

  useEffect(() => getMessage(), []);

  return (
    <div className="container-fluid">
      <div className="bg-secondary row text-light">
        <div className="col-3 m-2">
          <h2>MyChatApp</h2>
        </div>
        <div className="col-6 m-3">
          <h5>by (Vinayak Bhat) (210940320134)</h5>
        </div>
      </div>
      <div className="form form-control m-3">
        <input
          type="text"
          value={chat}
          onChange={handleChatChange}
          placeholder="Lets chat here..."
        />

        <input type="button" value="SEND" onClick={addMessage} />
      </div>

      <div>
        {list.map((item, index) => (
          <div className="form form-control m-3" key={index}>
            {item.chat}
          </div>
        ))}
      </div>
    </div>
  );
}
